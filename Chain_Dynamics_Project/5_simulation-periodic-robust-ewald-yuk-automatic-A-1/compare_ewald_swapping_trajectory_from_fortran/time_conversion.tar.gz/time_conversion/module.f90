
module parameters
  implicit none

  real*8 :: pi = 4.d0 * atan(1.d0),Cw = 1.3105329259d0
  real*8 :: f_sigma=0.5,sigma!!!!0.5d0!0.01d0!0.33333333d0!0.5d0
  real*8 :: n=1.d0
  integer :: m=2
  integer :: n1max=2, m1max=10
  integer :: depth=200
  complex *16 :: i=dcmplx(0.d0,1.d0)
  !character(5) :: flag

end module parameters
!___________________________!
module parameters2
  implicit none

  integer :: imax=25
  real*8 :: ini_valx=0.005d0,incre_x=0.001d0,h=0.0000001

end module parameters2
!___________________________!
module parameters_kn
  implicit none

  real*8 :: k_n(2),k_nmod

end module parameters_kn

!__________________________!
module flag_self_int
  implicit none
  logical :: flag_self
end module flag_self_int

!The most generic parameters for any particle arrangement
module main_module
  implicit none

  integer :: numpar
  real*8 :: af
  real*8 :: Lx=23.04d0,Ly=3.84d0
  real*8 :: dia=1.d0
  
end module main_module

!Has variables related expressly to rectangular particle arrangement
module rectangle
  implicit none

  real*8 :: Nx,Ny
  real*8 :: p_sf_x,p_sf_y
  real*8 :: del_x=0.d0,del_y=0.d0
  
end module rectangle

module random_parameters
  implicit none
  integer :: seed_val
  integer, dimension(12) :: seed
  real*8 :: factor
end module random_parameters

module new_cood_yukawa
  implicit none
  real*8 :: new_relpos(2)
end module new_cood_yukawa

module velocities
  implicit none

  real*8 :: pos_diff(2)
  real*8 :: V1(2),V2(2)
end module velocities

module yukawa_para
  implicit none
  real*8 :: ka,A
  integer :: m_yuk
end module yukawa_para
!Has only variables related to reavealing/storing configuration
!module configuration
!  implicit none
!  real*8, allocatable :: y(:), yo(:), dy(:)
!  real*8, allocatable :: y_unit(:)
  
!end module configuration
