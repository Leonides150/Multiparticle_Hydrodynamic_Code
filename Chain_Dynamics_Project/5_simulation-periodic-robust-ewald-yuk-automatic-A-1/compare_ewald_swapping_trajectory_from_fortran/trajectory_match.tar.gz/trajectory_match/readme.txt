1. The links setup in the gnuplot file has to be changed to the present locations of the dat files for the gnuplot to run, which is the present directory.
2. the dat files in the format dx2-1_deriv.dat and so on are from Abhilash and the numbers in the file demarcate the initial separations at from which the two-particle simulations were started.
3. Files named like swap_traj_fit_2-7_2.dat(short-field) or swap_traj_fit_8_1.dat(far-field) contain both Abhilash's and our data in this order:
y(2*i-1),y(2*i),dy(2*i-1),dy(2*i),REALPART(ewald_sum(1)),REALPART(ewald_sum(2)),v_s

y - relative position
dy - Abhilash's velocity
v_s - our swapping trajectory velocity


