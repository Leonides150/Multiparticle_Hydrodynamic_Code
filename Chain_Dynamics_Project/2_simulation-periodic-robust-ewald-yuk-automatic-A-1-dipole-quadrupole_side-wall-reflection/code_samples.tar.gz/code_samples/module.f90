module parameters
  implicit none

  real*8 :: pi = 4.d0 * atan(1.d0),Cw = 1.3105329259d0
  real*8 :: f_sigma=0.5,sigma!!!!0.5d0!0.01d0!0.33333333d0!0.5d0
  real*8 :: n=1.d0
  integer :: m
  integer :: n1max=3, m1max=3! n1max=10, m1max=10
  integer :: depth=200
  complex *16 :: i=dcmplx(0.d0,1.d0)
  !character(5) :: flag

end module parameters
!___________________________!
module parameters2
  implicit none

  integer :: imax=25
  real*8 :: ini_valx=0.005d0,incre_x=0.001d0,h=0.0000001

end module parameters2
!___________________________!
module parameters_kn
  implicit none

  real*8 :: k_n(2),k_nmod

end module parameters_kn

!__________________________!
module flag_self_int
  implicit none
  logical :: flag_self
end module flag_self_int

!The most generic parameters for any particle arrangement
module main_module
  implicit none

  integer :: numpar
  real*8 :: af
  real*8 :: Lx,Ly
  real*8 :: dia=1.d0
  real*8 :: dt
  
end module main_module

!Has variables related expressly to rectangular particle arrangement
module rectangle
  implicit none

  real*8 :: Nx,Ny
  real*8 :: p_sf_x,p_sf_y
  real*8 :: del_x=0.d0,del_y=0.d0
  
end module rectangle

module random_parameters
  implicit none
  integer :: seed_val
  integer, dimension(12) :: seed
  real*8 :: factor
  real*8 :: frac_x=0.48d0, frac_y=0.5d0, shift_frac=0.25d0 !frac_x=0.25d0, frac_y=0.5d0, shift_frac=0.25d0 !frac_x=0.18d0, frac_y=0.5d0, shift_frac=0.25d0 !frac_x=0.32d0, frac_y=0.5d0, shift_frac=0.25d0 !frac_x=1.d0, frac_y=0.5d0, shift_frac=0.d0
  !real*8 :: frac_x=1.d0, frac_y=0.5d0, shift_frac=0.d0
  !real*8 :: frac_x=0.5d0, frac_y=0.5d0, shift_frac=0.25d0
end module random_parameters

module new_cood_yukawa
  implicit none
  real*8 :: new_relpos(2)
end module new_cood_yukawa

module velocities
  implicit none

  real*8 :: pos_diff(2)
  real*8 :: V_d(2),V_q(2),V2(2)
end module velocities

module yukawa_para
  implicit none
  real*8 :: ka,A
  integer :: m_yuk
end module yukawa_para

module two_particles_para
  implicit none
  real*8 :: drho(2),drho_new(2)
  integer :: pair_num,numpar_extra
end module two_particles_para

module swap_traj_para
  implicit none
  real*8 :: kappa=6.5d0
  !real*8 :: kappa=5.8d0
  !real*8 :: b=0.d0,x0=1.95d0
  real*8 :: b=0.5d0,x0=1.90d0
  real*8 :: Aswap=2.3214711563643968d0
end module swap_traj_para
!Has only variables related to reavealing/storing configuration
!module configuration
!  implicit none
!  real*8, allocatable :: y(:), yo(:), dy(:)
!  real*8, allocatable :: y_unit(:)
  
!end module configuration

module gauss_para
  implicit none
  real*8, allocatable :: gauss_vel(:)
  real*8 :: g_stren
end module gauss_para

module para_bk
  implicit none
  real*8 :: alpha_bk=1.d0,m_bk=1.d0,g_sq=1.3205559789992223d0
  !real*8 :: x_st_bk= 18.d0!9.d0 !18.d0!9.d0!8.8d0 !1.d0 !!!100p
  real*8 :: x_st_bk=36.d0!9.d0!x_st_bk=36.d0!x_st_bk=36.5d0 !36.d0  !200p !0.d0!9.d0        !!!50 p
  real*8 :: x_st_ft=140.d0, frac_ft=1.d0 !x_st_ft=95.d0, frac_ft=1.d0 !x_st_ft=96.5d0, frac_ft=1.d0!90.d0, frac_ft=1.d0 !200p x_st_ft=120.d0, frac_ft=1.d0 !50 p x_st_ft=30.d0, frac_ft=1.d0 
  real*8 :: v_front = 0.2d0!0.2d0 !0.15d0 !0.2d0!0.4d0 !0.45d0 !!!100p or 50 p too
  !real*8 :: v_front =  0.25d0 !0.2d0 !0.25d0 !!!0.288d0 !!! 0.394d0 !!!for 50p!!!
  
end module para_bk
